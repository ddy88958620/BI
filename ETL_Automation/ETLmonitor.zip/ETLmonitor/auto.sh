#!/bin/sh

if [ $# -ne 2 ]; then
echo "Usage: sh auto.sh BGN_YYYYMMDD END_YYYYMMDD"
exit
else
txdate=$1
maxdate=$2
echo "  ###### txdate=$txdate,maxdate=$maxdate ######  "
sleep 10
fi

while [ $txdate -le $maxdate ]
do
cp -f ETLmonitor.cfg.bak ETLmonitor.cfg
sed -i "s/20130903/$txdate/" ETLmonitor.cfg
cat ETLmonitor.cfg
echo "
              #################################               
"
sleep 10
sh ETLmonitor1.sh T
sh ETLmonitor1.sh C
sh ETLmonitor1.sh M
sh ETLmonitor1.sh U05
sh ETLmonitor1.sh U06

txdate=`date -d "$txdate 1 days" +"%Y%m%d"`
echo "  ###### txdate=$txdate,maxdate=$maxdate ######  "
sleep 10
done

