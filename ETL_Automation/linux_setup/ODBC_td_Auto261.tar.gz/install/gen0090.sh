#0090
perl ${AUTO_HOME}/bin/scriptwz.pl -ds ${AUTO_DSN} -logon npcds,npcds -sys PB1 -db SDDL -table ACT_ACCOUNT -logdb dp_mcif_load_error -job bteq -home ${AUTO_HOME} -otype perl -dformat unformatted
perl ${AUTO_HOME}/bin/scriptwz.pl -ds ${AUTO_DSN} -logon npcds,npcds -sys PB1 -db SDDL -table ACT_GUART -logdb dp_mcif_load_error -job bteq -home ${AUTO_HOME} -otype perl -dformat unformatted
perl ${AUTO_HOME}/bin/scriptwz.pl -ds ${AUTO_DSN} -logon npcds,npcds -sys PB1 -db SDDL -table ACT_ID_CHANGE -logdb dp_mcif_load_error -job bteq -home ${AUTO_HOME} -otype perl -dformat unformatted
perl ${AUTO_HOME}/bin/scriptwz.pl -ds ${AUTO_DSN} -logon npcds,npcds -sys PB1 -db SDDL -table PTY_RESIDENCE -logdb dp_mcif_load_error -job bteq -home ${AUTO_HOME} -otype perl -dformat unformatted
perl ${AUTO_HOME}/bin/scriptwz.pl -ds ${AUTO_DSN} -logon npcds,npcds -sys PB1 -db SDDL -table PTY_OCCUPATION -logdb dp_mcif_load_error -job bteq -home ${AUTO_HOME} -otype perl -dformat unformatted
perl ${AUTO_HOME}/bin/scriptwz.pl -ds ${AUTO_DSN} -logon npcds,npcds -sys PB1 -db SDDL -table PTY_INDIVIDUAL -logdb dp_mcif_load_error -job bteq -home ${AUTO_HOME} -otype perl -dformat unformatted
perl ${AUTO_HOME}/bin/scriptwz.pl -ds ${AUTO_DSN} -logon npcds,npcds -sys PB1 -db SDDL -table ACT_SPEC_TXN -logdb dp_mcif_load_error -job bteq -home ${AUTO_HOME} -otype perl -dformat unformatted
perl ${AUTO_HOME}/bin/scriptwz.pl -ds ${AUTO_DSN} -logon npcds,npcds -sys PB1 -db SDDL -table ACT_SPEC_COMMENT -logdb dp_mcif_load_error -job bteq -home ${AUTO_HOME} -otype perl -dformat unformatted
perl ${AUTO_HOME}/bin/scriptwz.pl -ds ${AUTO_DSN} -logon npcds,npcds -sys PB1 -db SDDL -table MESSAGE_HEAD -logdb dp_mcif_load_error -job bteq -home ${AUTO_HOME} -otype perl -dformat unformatted
