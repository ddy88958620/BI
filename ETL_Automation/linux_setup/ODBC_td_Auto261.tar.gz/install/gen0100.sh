#0100
perl ${AUTO_HOME}/bin/scriptwz.pl -ds ${AUTO_DSN} -logon bill,bill -sys TST -db bill -table tab1 -job fload -home ${AUTO_HOME} -otype perl -dformat vartext -deli \|
